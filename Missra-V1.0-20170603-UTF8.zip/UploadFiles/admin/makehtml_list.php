<?php
/**
 * 生成列表栏目
 *
 * @version        $Id: makehtml_list.php
 * @package        Mi.Administrator
 * @copyright      Copyright (c)  2010, Missra
 * @license        http://help.missra.com/usersguide/license.html
 * @link           http://www.missra.com
 */
require_once(dirname(__FILE__)."/config.php");
require_once(MIINC."/typelink.class.php");
include MiInclude('templets/makehtml_list.htm');