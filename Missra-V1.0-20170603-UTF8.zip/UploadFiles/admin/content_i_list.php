<?php
/**
 * 内容列表
 *
 * @version        $Id: content_i_list.php
 * @package        Mi.Administrator
 * @copyright      Copyright (c)  2010, Missra
 * @license        http://help.missra.com/usersguide/license.html
 * @link           http://www.missra.com
 */
$s_tmplets = "templets/content_i_list.htm";
include(dirname(__FILE__)."/content_list.php");