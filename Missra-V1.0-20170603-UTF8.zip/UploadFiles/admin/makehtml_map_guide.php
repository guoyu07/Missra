<?php
/**
 * 生成网站地图向导
 *
 * @version        $Id: makehtml_map_guide.php
 * @package        Mi.Administrator
 * @copyright      Copyright (c)  2010, Missra
 * @license        http://help.missra.com/usersguide/license.html
 * @link           http://www.missra.com
 */
require_once(dirname(__FILE__)."/config.php");
include MiInclude('templets/makehtml_map_guide.htm');