<?php
/**
 * 管理后台顶部
 *
 * @version        $Id: index_top.php
 * @package        Mi.Administrator
 * @copyright      Copyright (c)  2010, Missra, Inc.
 * @license        http://help.missra.com/usersguide/license.html
 * @link           http://www.missra.com
 */
require(dirname(__FILE__)."/config.php");

include MiInclude('templets/index_top.htm');

// if($cuserLogin->adminStyle == 'missra') {
//     include MiInclude('templets/index_top.htm');
// } else {
//     include MiInclude('templets/index_top2.htm');
// }
