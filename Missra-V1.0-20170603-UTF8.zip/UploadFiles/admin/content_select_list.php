<?php
/**
 * 选择文章
 *
 * @version        $Id: content_select_list.php
 * @package        Mi.Administrator
 * @copyright      Copyright (c)  2010, Missra
 * @license        http://help.missra.com/usersguide/license.html
 * @link           http://www.missra.com
 */
$s_tmplets = "templets/content_select_list.htm";
include(dirname(__FILE__)."/content_list.php");
