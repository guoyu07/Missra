<?php
/**
 * 生成RSS地图
 *
 * @version        $Id: makehtml_rss.php
 * @package        Mi.Administrator
 * @copyright      Copyright (c)  2010, Missra
 * @license        http://help.missra.com/usersguide/license.html
 * @link           http://www.missra.com
 */
require_once(dirname(__FILE__)."/config.php");
include MiInclude('templets/makehtml_rss.htm');