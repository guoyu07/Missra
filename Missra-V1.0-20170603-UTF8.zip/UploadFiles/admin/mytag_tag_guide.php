<?php
/**
 * 自定义标记向导
 *
 * @version        $Id: mytag_tag_guide.php
 * @package        Mi.Administrator
 * @copyright      Copyright (c)  2010, Missra
 * @license        http://help.missra.com/usersguide/license.html
 * @link           http://www.missra.com
 */
require_once(dirname(__FILE__)."/config.php");
require_once(MIINC."/typelink.class.php");
include MiInclude('templets/mytag_tag_guide.htm');