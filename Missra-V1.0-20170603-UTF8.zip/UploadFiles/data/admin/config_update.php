<?php
/**
 * 更新服务器，如果有变动，请到 http://bbs.missra.com 查询
 *
 * @version        $Id: config_update.php
 * @package        Mi.Administrator
 * @copyright      Copyright (c) 2010, Mi, Inc.
 * @license        http://help.missra.com/usersguide/license.html
 * @link           http://www.missra.com
 */

//更新服务器，如果有变动，请到 http://bbs.missra.com 查询
$updateHost = 'http://updatenew.missra.com/base-v57/';
$linkHost = 'http://flink.missra.com/server_url.php';
